/* 2K Dashboard © 2026 — uso licenciado. Redistribuição proibida. */
import"dotenv/config";import o from"pino";export const logger=o({level:process.env.LOG_LEVEL??"info"});