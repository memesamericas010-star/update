/* 2K Dashboard © 2026 — uso licenciado. Redistribuição proibida. */
export const CHAVE_PUBLICA_B64="MCowBQYDK2VwAyEAnM0ueDM1AcsfKmlcvKX9O3ZQGOKwceLp-FNsNh6halQ";