#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
#  2K Dashboard — atualizador seguro para VPS (Ubuntu/Debian, systemd)
#
#  Você coloca a pasta (ou .tar.gz) da versão nova na VPS e roda:
#
#     sudo bash atualizar.sh                    # pega a mais nova em /opt/2k-dashboard-atualizacoes
#     sudo bash atualizar.sh /caminho/da/nova   # pasta ou .tar.gz específico
#     sudo bash atualizar.sh --listar           # backups disponíveis
#     sudo bash atualizar.sh --reverter [nome]  # volta para um backup (padrão: o último)
#     sudo bash atualizar.sh --instalar-timer   # aplica sozinho o que cair na pasta de entrada
#
#  O que ele faz, nesta ordem:
#     1. valida o pacote novo (arquivos obrigatórios, sintaxe do JS, sem segredos);
#     2. para o serviço;
#     3. MOVE o código antigo para /opt/2k-dashboard-backups/<data>-<versão>/
#        (dados, licença, sessão do WhatsApp, uploads e .env FICAM no lugar);
#     4. copia o código novo por cima;
#     5. reinstala dependências só se o package-lock.json mudou;
#     6. sobe o serviço e confere o /health;
#     7. se não subir, DESFAZ tudo sozinho (volta o código antigo) e avisa.
#
#  Opções:  --sim (não pergunta)  --npm (força npm ci)  --sem-npm  --manter N
#           --auto (silencioso; para usar no timer)  --apagar-origem
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

APP="${APP:-2k-dashboard}"
DIR_APP="${DIR_APP:-/opt/${APP}}"
DIR_ENTRADA="${DIR_ENTRADA:-/opt/${APP}-atualizacoes}"
DIR_BACKUPS="${DIR_BACKUPS:-/opt/${APP}-backups}"
USUARIO="${USUARIO:-2kbot}"
MANTER="${MANTER:-5}"                 # quantos backups guardar
ESPERA_SAUDE="${ESPERA_SAUDE:-40}"    # segundos aguardando o serviço responder
QUIETUDE="${QUIETUDE:-90}"            # --auto: ignora pastas alteradas há menos de N s (upload em curso)

# O que NUNCA é movido nem sobrescrito (dados de execução do cliente).
PRESERVAR=(.env data auth uploads certs node_modules .maquina-id licenca.key .preservar)

vermelho(){ printf '\033[31m%s\033[0m\n' "$*"; }
verde()   { printf '\033[32m%s\033[0m\n' "$*"; }
azul()    { printf '\033[36m%s\033[0m\n' "$*"; }
amarelo() { printf '\033[33m%s\033[0m\n' "$*"; }
falha()   { vermelho "✖ $*"; exit 1; }

# ── Roda a partir de uma CÓPIA de si mesmo: o arquivo original pode ser
#    sobrescrito pela atualização no meio da execução (bash lê o script aos
#    poucos), o que corromperia o processo.
if [ -z "${ATUALIZADOR_COPIA:-}" ]; then
  _T="$(mktemp)"; cp "$0" "$_T"
  ATUALIZADOR_COPIA="$_T" exec bash "$_T" "$@"
fi
trap 'rm -f "$ATUALIZADOR_COPIA"' EXIT

# ── Argumentos ─────────────────────────────────────────────────────────────
ORIGEM=""; MODO="atualizar"; SIM=0; NPM="auto"; AUTO=0; APAGAR_ORIGEM=0; ALVO_REVERTER=""
while [ $# -gt 0 ]; do
  case "$1" in
    --listar)          MODO="listar" ;;
    --reverter)        MODO="reverter"; [ $# -gt 1 ] && [[ "$2" != --* ]] && { ALVO_REVERTER="$2"; shift; } ;;
    --instalar-timer)  MODO="timer" ;;
    --sim|-y)          SIM=1 ;;
    --npm)             NPM="sim" ;;
    --sem-npm)         NPM="nao" ;;
    --manter)          MANTER="$2"; shift ;;
    --auto)            AUTO=1; SIM=1 ;;
    --apagar-origem)   APAGAR_ORIGEM=1 ;;
    -h|--help)         sed -n '2,25p' "$0" | sed 's/^# \{0,2\}//'; exit 0 ;;
    --*)               falha "opção desconhecida: $1" ;;
    *)                 ORIGEM="$1" ;;
  esac
  shift
done

# systemd pode não existir (testes locais); aí só mexe nos arquivos.
TEM_SYSTEMD=1
if [ "${SEM_SERVICO:-0}" = "1" ] || ! command -v systemctl >/dev/null 2>&1; then TEM_SYSTEMD=0; fi
if [ "$TEM_SYSTEMD" = "1" ] && [ "$(id -u)" -ne 0 ]; then falha "Rode como root:  sudo bash atualizar.sh"; fi

mkdir -p "$DIR_ENTRADA" "$DIR_BACKUPS"
DIR_ENTRADA="$(cd "$DIR_ENTRADA" && pwd)"; DIR_BACKUPS="$(cd "$DIR_BACKUPS" && pwd)"
[ -d "$DIR_APP" ] && DIR_APP="$(cd "$DIR_APP" && pwd)"
chmod 700 "$DIR_BACKUPS" 2>/dev/null || true
LOG="$DIR_BACKUPS/atualizacoes.log"
log(){ printf '%s  %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"; }

# Trava: duas atualizações ao mesmo tempo seria desastre.
TRAVA="$DIR_BACKUPS/.trava"
if ! mkdir "$TRAVA" 2>/dev/null; then
  # trava órfã (processo morreu)? se o PID gravado não existe, assume.
  PID_ANT="$(cat "$TRAVA/pid" 2>/dev/null || true)"
  if [ -n "$PID_ANT" ] && kill -0 "$PID_ANT" 2>/dev/null; then
    [ "$AUTO" = "1" ] && exit 0
    falha "Já existe uma atualização em andamento (pid $PID_ANT)."
  fi
  rm -rf "$TRAVA"; mkdir "$TRAVA"
fi
echo $$ > "$TRAVA/pid"
trap 'rm -rf "$TRAVA"; rm -f "$ATUALIZADOR_COPIA"' EXIT

# ── Utilidades ─────────────────────────────────────────────────────────────
e_preservado(){ local n; for n in "${PRESERVAR[@]}"; do [ "$1" = "$n" ] && return 0; done; return 1; }

# Itens extras a preservar, um por linha em $DIR_APP/.preservar (opcional).
if [ -f "$DIR_APP/.preservar" ]; then
  while IFS= read -r l; do l="${l%%#*}"; l="${l// /}"; [ -n "$l" ] && PRESERVAR+=("$l"); done < "$DIR_APP/.preservar"
fi

versao_de(){ node -p "try{JSON.parse(require('fs').readFileSync(process.argv[1],'utf8')).version||''}catch{''}" "$1/package.json" 2>/dev/null || true; }
build_de(){ sed -n '1,3p' "$1/BUILD.txt" 2>/dev/null | tr '\n' ' ' || true; }

servico(){ [ "$TEM_SYSTEMD" = "1" ] && systemctl "$@" "$APP" || true; }
servico_ativo(){ [ "$TEM_SYSTEMD" = "1" ] && systemctl is-active --quiet "$APP"; }

# Espera o app responder no /health (lê PORT/HOST/TLS do .env).
esperar_saude(){
  [ "$TEM_SYSTEMD" = "1" ] || { [ "${ATUALIZADOR_TESTE_FALHA:-0}" = "1" ] && return 1 || return 0; }
  local porta host proto url i
  porta="$(grep -E '^PORT=' "$DIR_APP/.env" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"'"'"' ' || true)"
  host="$(grep -E '^HOST=' "$DIR_APP/.env" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"'"'"' ' || true)"
  porta="${porta:-8480}"; host="${host:-127.0.0.1}"
  case "$host" in ""|0.0.0.0|::|"[::]") host=127.0.0.1;; esac
  proto=http; grep -qE '^TLS_CERT=.+' "$DIR_APP/.env" 2>/dev/null && proto=https
  url="${proto}://${host}:${porta}/health"
  for ((i=0; i<ESPERA_SAUDE; i++)); do
    if ! servico_ativo; then
      # saiu com 87 = sem licença; não adianta esperar
      if systemctl show "$APP" -p ExecMainStatus --value 2>/dev/null | grep -qx 87; then
        vermelho "Serviço saiu com código 87 (licença inválida para esta máquina)."; return 1
      fi
      systemctl is-failed --quiet "$APP" 2>/dev/null && { vermelho "Serviço entrou em estado 'failed'."; return 1; }
    fi
    if curl -fsk --max-time 3 "$url" 2>/dev/null | grep -q '"ok"'; then return 0; fi
    sleep 1
  done
  return 1
}

# Acha a raiz real do pacote (aceita pasta com uma subpasta única dentro).
achar_raiz(){
  local d="$1"
  if [ -f "$d/server.js" ]; then echo "$d"; return 0; fi
  local subs=(); local x
  for x in "$d"/*/; do [ -d "$x" ] && subs+=("${x%/}"); done
  if [ "${#subs[@]}" -eq 1 ] && [ -f "${subs[0]}/server.js" ]; then echo "${subs[0]}"; return 0; fi
  return 1
}

# Idade (segundos) do arquivo mais recente dentro de um caminho.
idade_min(){ local agora mais; agora="$(date +%s)"; mais="$(find "$1" -type f -printf '%T@\n' 2>/dev/null | sort -n | tail -1 | cut -d. -f1)"; echo $(( agora - ${mais:-0} )); }

# Move todos os itens de código de A para B (pulando os preservados).
mover_codigo(){ # origem destino
  local n base
  for n in "$1"/* "$1"/.[!.]*; do
    [ -e "$n" ] || continue
    base="$(basename "$n")"
    e_preservado "$base" && continue
    mv "$n" "$2/"
  done
}

listar_backups(){
  local b v
  echo "Backups em $DIR_BACKUPS:"
  for b in "$DIR_BACKUPS"/*/; do
    [ -d "$b" ] || continue
    b="${b%/}"; [ -f "$b/INFO.txt" ] || continue
    v="$(grep -E '^versao:' "$b/INFO.txt" | cut -d' ' -f2-)"
    printf '   %-32s versão %-10s %s\n' "$(basename "$b")" "${v:-?}" "$(grep -E '^motivo:' "$b/INFO.txt" | cut -d' ' -f2-)"
  done
}

# ── --listar ───────────────────────────────────────────────────────────────
if [ "$MODO" = "listar" ]; then listar_backups; echo; echo "Log: $LOG"; exit 0; fi

# ── --instalar-timer ───────────────────────────────────────────────────────
if [ "$MODO" = "timer" ]; then
  [ "$TEM_SYSTEMD" = "1" ] || falha "sem systemd aqui."
  cp "$ATUALIZADOR_COPIA" /usr/local/sbin/2k-atualizar && chmod 755 /usr/local/sbin/2k-atualizar
  cat > "/etc/systemd/system/${APP}-atualizador.service" <<UNIT
[Unit]
Description=2K Dashboard - aplica atualizações deixadas em ${DIR_ENTRADA}

[Service]
Type=oneshot
ExecStart=/bin/bash /usr/local/sbin/2k-atualizar --auto
UNIT
  cat > "/etc/systemd/system/${APP}-atualizador.timer" <<UNIT
[Unit]
Description=2K Dashboard - verifica a pasta de atualizações a cada 2 min

[Timer]
OnBootSec=3min
OnUnitActiveSec=2min
Unit=${APP}-atualizador.service

[Install]
WantedBy=timers.target
UNIT
  systemctl daemon-reload
  systemctl enable --now "${APP}-atualizador.timer" >/dev/null
  verde "Timer instalado. Basta colocar a pasta/.tar.gz nova em: $DIR_ENTRADA"
  echo "   Ela é aplicada em até 2 min (depois de ${QUIETUDE}s sem alterações, para não pegar upload pela metade)."
  echo "   Acompanhe: tail -f $LOG     |  desligar: systemctl disable --now ${APP}-atualizador.timer"
  exit 0
fi

# ── --reverter ─────────────────────────────────────────────────────────────
if [ "$MODO" = "reverter" ]; then
  if [ -n "$ALVO_REVERTER" ]; then
    B="$DIR_BACKUPS/$(basename "$ALVO_REVERTER")"
  else
    B="$(ls -1d "$DIR_BACKUPS"/*/ 2>/dev/null | grep -v '/falhou-\|/revertido-' | sort | tail -1 | sed 's:/$::')"
  fi
  [ -n "$B" ] && [ -f "$B/INFO.txt" ] || { listar_backups; falha "backup não encontrado: ${ALVO_REVERTER:-(nenhum)}"; }
  azul "── Reverter para: $(basename "$B") (versão $(grep -E '^versao:' "$B/INFO.txt" | cut -d' ' -f2-)) ──"
  if [ "$SIM" != "1" ] && [ -t 0 ]; then read -rp "Confirmar reversão? [s/N] " r; [[ "$r" =~ ^[sSyY] ]] || exit 1; fi
  servico stop
  ATUAL="$DIR_BACKUPS/revertido-$(date +%Y%m%d-%H%M%S)-v$(versao_de "$DIR_APP")"
  mkdir -p "$ATUAL"; mover_codigo "$DIR_APP" "$ATUAL"
  printf 'motivo: código substituído pela reversão para %s\nversao: %s\ndata: %s\n' "$(basename "$B")" "$(versao_de "$ATUAL")" "$(date -Is)" > "$ATUAL/INFO.txt"
  # volta o código (e o node_modules daquela época, se foi guardado)
  for n in "$B"/* "$B"/.[!.]*; do
    [ -e "$n" ] || continue; base="$(basename "$n")"
    case "$base" in INFO.txt|_dados-copia) continue;; esac
    if [ "$base" = "node_modules" ]; then rm -rf "$DIR_APP/node_modules"; fi
    mv "$n" "$DIR_APP/"
  done
  rmdir "$B" 2>/dev/null || mv "$B" "$DIR_BACKUPS/consumido-$(basename "$B")"
  [ "$TEM_SYSTEMD" = "1" ] && chown -R "$USUARIO":"$USUARIO" "$DIR_APP"
  servico start
  if esperar_saude; then verde "✔ Revertido e serviço no ar (versão $(versao_de "$DIR_APP"))."; log "REVERTIDO para $(basename "$B")"
  else amarelo "Revertido, mas o serviço não respondeu. Veja: journalctl -u $APP -n 50 --no-pager"; log "REVERTIDO para $(basename "$B") — serviço NÃO respondeu"; exit 2; fi
  exit 0
fi

# ── Atualizar: descobre a origem ───────────────────────────────────────────
if [ -z "$ORIGEM" ]; then
  # a entrada mais recente (pasta ou .tar.gz/.tgz) na pasta de atualizações
  ORIGEM="$(find "$DIR_ENTRADA" -mindepth 1 -maxdepth 1 \( -type d -o -name '*.tar.gz' -o -name '*.tgz' \) ! -name 'aplicadas' ! -name 'rejeitadas' -printf '%T@ %p\n' 2>/dev/null | sort -n | tail -1 | cut -d' ' -f2-)"
  if [ -z "$ORIGEM" ]; then
    [ "$AUTO" = "1" ] && exit 0
    falha "Nada para aplicar. Coloque a pasta (ou .tar.gz) da versão nova em: $DIR_ENTRADA"
  fi
fi
[ -e "$ORIGEM" ] || falha "não existe: $ORIGEM"
ORIGEM="$(cd "$(dirname "$ORIGEM")" && pwd)/$(basename "$ORIGEM")"

# --auto: não pega upload pela metade
if [ "$AUTO" = "1" ]; then
  IDADE="$(idade_min "$ORIGEM")"
  [ "$IDADE" -ge "$QUIETUDE" ] || { log "aguardando $ORIGEM (alterado há ${IDADE}s)"; exit 0; }
fi

exec > >(tee -a "$LOG") 2>&1
echo; azul "── 2K Dashboard · atualização ─────────────────────────────── $(date '+%Y-%m-%d %H:%M:%S')"

# ── Prepara o pacote novo em área temporária ───────────────────────────────
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP" "$TRAVA"; rm -f "$ATUALIZADOR_COPIA"' EXIT
case "$ORIGEM" in
  *.tar.gz|*.tgz)
    azul "Extraindo $(basename "$ORIGEM") ..."
    mkdir -p "$TMP/pacote"; tar -xzf "$ORIGEM" -C "$TMP/pacote"
    NOVO="$(achar_raiz "$TMP/pacote")" || falha "o .tar.gz não contém um 2K Dashboard (sem server.js)." ;;
  *)
    [ -d "$ORIGEM" ] || falha "origem precisa ser uma pasta ou .tar.gz: $ORIGEM"
    NOVO="$(achar_raiz "$ORIGEM")" || falha "a pasta não contém um 2K Dashboard (sem server.js)." ;;
esac
[ "$(cd "$NOVO" && pwd)" != "$(cd "$DIR_APP" && pwd)" ] || falha "a origem é a própria instalação."

# ── 1) Validação ───────────────────────────────────────────────────────────
azul "Validando pacote novo ..."
for f in server.js package.json src public; do
  [ -e "$NOVO/$f" ] || falha "pacote incompleto: falta $f"
done
[ ! -e "$NOVO/chaves-autor" ] || falha "o pacote contém chaves-autor/ (chave privada do autor). Recusado."
for f in .env data auth; do
  [ -e "$NOVO/$f" ] && amarelo "  aviso: o pacote traz '$f' — será IGNORADO (o da instalação é mantido)."
done
command -v node >/dev/null 2>&1 || falha "node não encontrado."
ERROS=0
while IFS= read -r js; do
  if ! node --check "$js" 2>"$TMP/erro.txt"; then ERROS=$((ERROS+1)); vermelho "  sintaxe inválida: ${js#$NOVO/}"; sed -n '1,4p' "$TMP/erro.txt" | sed 's/^/     /'; fi
done < <(find "$NOVO/server.js" "$NOVO/src" -name '*.js' -o -name '*.mjs' 2>/dev/null)
[ "$ERROS" -eq 0 ] || { [ "$ORIGEM" != "${ORIGEM#$DIR_ENTRADA/}" ] && { mkdir -p "$DIR_ENTRADA/rejeitadas"; mv "$ORIGEM" "$DIR_ENTRADA/rejeitadas/"; }; falha "$ERROS arquivo(s) com erro de sintaxe. Nada foi alterado."; }

V_ANTIGA="$(versao_de "$DIR_APP")"; V_NOVA="$(versao_de "$NOVO")"
echo "   instalado : versão ${V_ANTIGA:-?}  $(build_de "$DIR_APP")"
echo "   novo      : versão ${V_NOVA:-?}  $(build_de "$NOVO")"
echo "   origem    : $ORIGEM"

# Dependências: só reinstala se o lock mudou (ou se forçado / sem node_modules).
REINSTALAR=0
if [ "$NPM" = "sim" ]; then REINSTALAR=1
elif [ "$NPM" = "auto" ]; then
  if [ ! -d "$DIR_APP/node_modules" ]; then REINSTALAR=1
  elif ! cmp -s "$DIR_APP/package-lock.json" "$NOVO/package-lock.json" 2>/dev/null; then REINSTALAR=1; fi
fi
[ "$REINSTALAR" = "1" ] && echo "   npm       : package-lock mudou → npm ci --omit=dev" || echo "   npm       : dependências mantidas"

if [ "$SIM" != "1" ] && [ -t 0 ]; then read -rp "Aplicar atualização? [s/N] " r; [[ "$r" =~ ^[sSyY] ]] || { echo "cancelado."; exit 1; }; fi

# ── 2) Para o serviço ──────────────────────────────────────────────────────
[ "$TEM_SYSTEMD" = "1" ] && { azul "Parando o serviço ..."; systemctl stop "$APP"; }

# ── 3) Move o código antigo para o backup ──────────────────────────────────
BK="$DIR_BACKUPS/$(date +%Y%m%d-%H%M%S)-v${V_ANTIGA:-desconhecida}"
mkdir -p "$BK/_dados-copia"
azul "Guardando código antigo em $BK ..."
mover_codigo "$DIR_APP" "$BK"
# cópia de segurança (não move) do que é pequeno e crítico
cp -a "$DIR_APP/.env" "$BK/_dados-copia/" 2>/dev/null || true
cp -a "$DIR_APP/data/db.json" "$BK/_dados-copia/" 2>/dev/null || true
cp -a "$DIR_APP/data/2k.db" "$BK/_dados-copia/" 2>/dev/null || true   # serviço parado: cópia consistente
cp -a "$DIR_APP/data/licenca.key" "$BK/_dados-copia/" 2>/dev/null || true
[ "$REINSTALAR" = "1" ] && [ -d "$DIR_APP/node_modules" ] && mv "$DIR_APP/node_modules" "$BK/node_modules"
printf 'motivo: atualização %s → %s\nversao: %s\ndata: %s\norigem: %s\n' "${V_ANTIGA:-?}" "${V_NOVA:-?}" "${V_ANTIGA:-?}" "$(date -Is)" "$ORIGEM" > "$BK/INFO.txt"
chmod -R go-rwx "$BK" 2>/dev/null || true

desfazer(){
  vermelho "Desfazendo: voltando o código antigo ..."
  servico stop
  F="$DIR_BACKUPS/falhou-$(date +%Y%m%d-%H%M%S)-v${V_NOVA:-desconhecida}"; mkdir -p "$F"
  mover_codigo "$DIR_APP" "$F"
  printf 'motivo: atualização FALHOU (revertida automaticamente)\nversao: %s\ndata: %s\norigem: %s\n' "${V_NOVA:-?}" "$(date -Is)" "$ORIGEM" > "$F/INFO.txt"
  for n in "$BK"/* "$BK"/.[!.]*; do
    [ -e "$n" ] || continue; base="$(basename "$n")"
    case "$base" in INFO.txt|_dados-copia) continue;; esac
    [ "$base" = "node_modules" ] && rm -rf "$DIR_APP/node_modules"
    mv "$n" "$DIR_APP/"
  done
  rm -rf "$BK"
  [ "$TEM_SYSTEMD" = "1" ] && chown -R "$USUARIO":"$USUARIO" "$DIR_APP"
  servico start
  if esperar_saude; then amarelo "Código antigo restaurado e serviço no ar (versão ${V_ANTIGA:-?}). O pacote com problema ficou em $F"
  else vermelho "Código antigo restaurado, mas o serviço NÃO respondeu. Veja: journalctl -u $APP -n 50 --no-pager"; fi
  log "FALHOU ${V_ANTIGA:-?} → ${V_NOVA:-?} (origem $ORIGEM); revertido"
  exit 2
}

# ── 4) Copia o código novo ─────────────────────────────────────────────────
azul "Copiando código novo ..."
EXCL=(); for n in "${PRESERVAR[@]}"; do EXCL+=(--exclude="./$n"); done
if ! tar -C "$NOVO" "${EXCL[@]}" -cf - . | tar -C "$DIR_APP" -xf -; then desfazer; fi
mkdir -p "$DIR_APP/data" "$DIR_APP/auth"

# ── 5) Dependências ────────────────────────────────────────────────────────
if [ "$REINSTALAR" = "1" ]; then
  azul "Instalando dependências (npm ci --omit=dev) ..."
  if ! ( cd "$DIR_APP" && { [ -f package-lock.json ] && npm ci --omit=dev || npm install --omit=dev; } ); then desfazer; fi
fi
if [ "$TEM_SYSTEMD" = "1" ]; then
  chown -R "$USUARIO":"$USUARIO" "$DIR_APP"
  chmod 600 "$DIR_APP/.env" 2>/dev/null || true
fi

# ── 6) Sobe e confere ──────────────────────────────────────────────────────
[ "$TEM_SYSTEMD" = "1" ] && { azul "Iniciando o serviço ..."; systemctl start "$APP" || true; }
if ! esperar_saude; then
  [ "$TEM_SYSTEMD" = "1" ] && journalctl -u "$APP" -n 25 --no-pager 2>/dev/null | sed 's/^/   │ /' || true
  desfazer
fi

# ── 7) Arruma a casa ───────────────────────────────────────────────────────
if [ "$ORIGEM" != "${ORIGEM#$DIR_ENTRADA/}" ]; then
  if [ "$APAGAR_ORIGEM" = "1" ]; then rm -rf "$ORIGEM"
  else mkdir -p "$DIR_ENTRADA/aplicadas"; rm -rf "$DIR_ENTRADA/aplicadas/$(basename "$ORIGEM")"; mv "$ORIGEM" "$DIR_ENTRADA/aplicadas/"; fi
fi
# mantém só os N backups mais recentes de cada tipo (normais; falhou/revertido/consumido)
podar(){ # padrão-grep(-v|"") : apaga os mais antigos além de MANTER
  { ls -1d "$DIR_BACKUPS"/*/ 2>/dev/null | grep $1 '/falhou-\|/revertido-\|/consumido-' || true; }     | while read -r d; do echo "$(stat -c %Y "$d") $d"; done | sort -n | head -n -"$MANTER" | cut -d' ' -f2-     | while read -r velho; do rm -rf "$velho"; done || true
}
podar -v; podar -e

echo
verde "════════════════════════════════════════════════════════════"
verde " Atualizado: ${V_ANTIGA:-?} → ${V_NOVA:-?}  ·  serviço no ar"
verde "════════════════════════════════════════════════════════════"
echo "   backup do antigo : $BK"
echo "   reverter         : sudo bash $DIR_APP/atualizar.sh --reverter"
echo "   log              : $LOG"
log "OK ${V_ANTIGA:-?} → ${V_NOVA:-?} (origem $ORIGEM; backup $BK)"
